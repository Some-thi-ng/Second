from django.contrib import admin
from .models import Like

admin.site.register(Like)
