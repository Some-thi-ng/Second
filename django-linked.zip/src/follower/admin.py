from django.contrib import admin
from .models import Follower

admin.site.register(Follower)
